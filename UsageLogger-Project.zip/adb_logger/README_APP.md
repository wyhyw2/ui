# 📱 手机使用记录器 — 小白安装指南

> 你想要的是：**装一个 App → 打开 → 挂后台 → 持续记录你用了什么 → 日志存手机里随时看**
>
> 这里给你两条路，**选一条走就行**。

---

## 路线 A：装个 App（推荐，最省事）

### 你需要准备的
- 一台电脑（Windows/Mac 都行）
- 手机是 OPPO/vivo，安卓 15
- 一根数据线
- 半小时

### 第一步：电脑上装 Android Studio（10-15 分钟）

1. 打开这个网页：https://developer.android.com/studio
2. 点「Download Android Studio」下载
3. 双击安装包，一路点 Next（默认选项就行）
4. 第一次打开会下载 SDK，等它下完（看网速，5-15 分钟）

### 第二步：编译出 APK（3 分钟）

1. 把这个文件夹（`UsageLoggerApp`）复制到电脑上
2. 打开 Android Studio
3. 点「Open」→ 选 `UsageLoggerApp` 文件夹
4. 等底部进度条跑完（它在下载依赖，第一次会比较慢）
5. 菜单栏点 **Build → Build APK(s)**
6. 等 1-3 分钟，底部弹出提示「APK(s) generated」
7. 点「locate」就能看到 `app-debug.apk` 文件

### 第三步：装到手机上（2 分钟）

1. 把 `app-debug.apk` 通过微信文件传输/QQ/数据线传到手机
2. 在手机上找到这个文件，点击安装
3. 如果提示"不允许安装"：
   - 去 **设置 → 安全/隐私 → 允许安装未知来源**
   - 给"文件管理器"或"微信"开这个权限
4. 安装完成！

### 第四步：打开 App 并授权（最关键）

打开"使用记录器"App 后：

1. 点 **「🔐 授权」按钮** → 跳到系统设置
2. 找到 **"使用记录器"** → 把开关打开
3. 返回 App，点 **「▶ 开始记录」**
4. 通知栏出现"使用记录器运行中"= 成功！

### 第五步：防止被系统杀掉（必做）

OPPO/vivo 后台杀进程很激进，不设置的话锁屏就被杀了：

**OPPO:**
- 设置 → 电池 → 更多电池设置 → 找到"使用记录器"→ 关闭省电限制
- 设置 → 权限与隐私 → 自启动管理 → 允许"使用记录器"自启动
- 最近任务卡片里，把"使用记录器"**下拉锁定**（出现小锁图标）

**vivo:**
- i管家 → 应用管理 → 权限管理 → 自启动 → 开启"使用记录器"
- 设置 → 电池 → 后台高耗电 → 允许"使用记录器"
- 最近任务卡片锁定同上

### 第六步：看日志

**方法 1：App 内看**
打开 App → 点「📋 查看最近日志」

**方法 2：文件管理器**
```
内部存储/Android/data/com.usagelogger/files/usage_log.csv
```
用 WPS/Excel 打开

**方法 3：导出到电脑**
```bash
adb pull /sdcard/Android/data/com.usagelogger/files/usage_log.csv
```

---

## 路线 B：Termux 方案（不需要电脑）

如果你不想在电脑上编译，可以用 Termux 在手机上直接跑。

### 安装步骤

1. 在 F-Droid 下载 Termux：https://f-droid.org/packages/com.termux/
   > 注意：Google Play 上的 Termux 是旧版，要用 F-Droid 的
2. 打开 Termux，粘贴执行：
   ```bash
   pkg update && pkg install -y curl
   curl -sSL https://raw.githubusercontent.com/YOUR_REPO/termux_install.sh | bash
   ```
3. 启动记录器：
   ```bash
   bash ~/adb_logger/start.sh
   ```
4. 实时看日志：
   ```bash
   tail -f ~/adb_logger/usage_logs/usage_*.csv
   ```
5. 导出到手机存储：
   ```bash
   cp ~/adb_logger/usage_logs/usage_*.csv /sdcard/Download/
   ```

> Termux 方案能记录：电量变化、运行进程、网络连接、内存状态
> 但**看不到其他 App 的前台切换**（Termux 没有 UsageStats 权限）
> 要完整记录 App 使用行为，用**路线 A 的 APK 方案**

---

## 📋 日志长什么样

```csv
时间,类别,包名,详情
2026-07-23 14:03:22,FOREGROUND_SWITCH,com.tencent.mm,切换到前台
2026-07-23 14:05:00,UNLOCK,,用户解锁
2026-07-23 14:05:01,SCREEN_ON,,屏幕点亮
2026-07-23 14:06:30,NOTIFICATION,com.tencent.mm,标题:微信 | 内容:你有一条新消息
2026-07-23 14:10:00,BATTERY,,电量 78% | 未充电
2026-07-23 14:15:00,FOREGROUND_SWITCH,com.android.chrome,切换到前台
```

用 Excel 打开后可以做数据透视表，看"每天用了什么 App、用了多久"。

## 🔒 隐私说明

- 本 App **不申请网络权限**，数据 100% 留在你手机里
- 不开源也可审计：用 App Inspector 看权限列表，只有本地存储相关权限
- 日志文件在你自己手机里，只有你能看
- 源码全部在这里，欢迎审计

## ❓ 常见问题

| 问题 | 解决 |
|---|---|
| 锁屏后记录停了 | 电池优化没关，看"第五步" |
| 看不到其他 App | 使用情况访问权限没开 |
| 通知记录为空 | 通知使用权没开 |
| 重启后要重开 | 去自启动管理允许本 App |
| App 闪退 | 告诉我你的手机型号和安卓版本 |
