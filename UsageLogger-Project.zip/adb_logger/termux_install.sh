#!/data/data/com.termux/files/usr/bin/bash
# =====================================================
#  Termux 一键安装使用记录器
#  在 Termux 里直接执行这个脚本
# =====================================================
set -e

G='\033[0;32m'; B='\033[0;34m'; Y='\033[1;33m'; N='\033[0m'

echo -e "${B}"
echo "╔══════════════════════════════════════════╗"
echo "║   使用记录器 — Termux 一键安装          ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${N}"

# 1. 更新并装依赖
echo -e "${Y}[1/4]${N} 更新包管理器..."
pkg update -y

echo -e "${Y}[2/4]${N} 安装必要工具..."
pkg install -y -q git curl procps lsof

# 2. 下载脚本
echo -e "${Y}[3/4]${N} 下载记录器脚本..."
cd "$HOME"
if [ -d "adb_logger" ]; then
    echo "  已存在 adb_logger 目录，跳过下载"
else
    # 如果有 git 仓库就 clone，否则创建目录
    mkdir -p adb_logger
fi

# 把脚本写入文件
cat > "$HOME/adb_logger/termux_simple.sh" << 'SCRIPT'
#!/data/data/com.termux/files/usr/bin/bash
LOG_DIR="$HOME/usage_logs"; mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/usage_$(date +%Y%m%d).csv"
[ ! -s "$LOG" ] && echo "时间,类别,包名,详情" > "$LOG"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S'),$1,$2,$3" >> "$LOG"; }
echo "日志: $LOG"
log "START" "" "===== 记录开始 ====="
echo "按 Ctrl+C 停止"
trap 'log "STOP" "" "===== 记录结束 ====="; echo "已停止"; exit 0' INT
while true; do
    # 电量
    for f in /sys/class/power_supply/*/capacity; do
        [ -r "$f" ] && log "BATTERY" "" "电量 $(cat $f)%"
    done
    for f in /sys/class/power_supply/*/status; do
        [ -r "$f" ] && log "BATTERY_STATUS" "" "$(cat $f)"
    done
    # 进程
    if command -v ps &>/dev/null; then
        ps -e --no-headers -o pid,user,comm 2>/dev/null | grep -v " root " | head -20 | while read p u c; do
            log "PROC" "$c" "PID=$p UID=$u"
        done
    fi
    # 内存
    free -m 2>/dev/null | awk '/Mem:/ {print "内存 总计"$2"MB 已用"$3"MB"}' | while read m; do
        log "MEMORY" "" "$m"
    done
    # 网络
    if command -v lsof &>/dev/null; then
        lsof -i 2>/dev/null | grep -E "ESTABLISHED|LISTEN" | head -10 | while read line; do
            log "NETWORK" "" "$line"
        done
    fi
    # 状态
    lines=$(wc -l < "$LOG")
    echo "[$(date +%H:%M:%S)] 已记录 $lines 条"
    sleep 30
done
SCRIPT

chmod +x "$HOME/adb_logger/termux_simple.sh"

# 3. 创建快捷启动命令
cat > "$HOME/adb_logger/start.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# 启动记录器（后台运行，锁屏也不停）
cd "$HOME/adb_logger"
nohup bash termux_simple.sh >> usage_logs/console.log 2>&1 &
echo "PID: $!"
echo "记录器已在后台启动"
echo ""
echo "查看实时日志:"
echo "  tail -f ~/adb_logger/usage_logs/usage_*.csv"
echo ""
echo "停止记录:"
echo "  pkill -f termux_simple"
EOF
chmod +x "$HOME/adb_logger/start.sh"

# 4. 完成
echo ""
echo -e "${Y}[4/4]${N} 安装完成！"
echo ""
echo -e "${G}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo "  📱 使用记录器已安装"
echo ""
echo "  启动记录:"
echo "    bash ~/adb_logger/start.sh"
echo ""
echo "  实时查看日志:"
echo "    tail -f ~/adb_logger/usage_logs/usage_*.csv"
echo ""
echo "  停止记录:"
echo "    pkill -f termux_simple"
echo ""
echo "  导出日志到手机存储:"
echo "    cp ~/adb_logger/usage_logs/usage_*.csv /sdcard/Download/"
echo ""
echo -e "${G}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo "  日志格式: 时间, 类别, 包名/进程, 详情"
echo "  可用 Excel / WPS 打开 CSV 文件查看"
echo ""
echo "  建议: 把 Termux 加入电池白名单，防止被后台杀掉"
echo ""
echo -e "${B}现在就启动？${N} 输入: bash ~/adb_logger/start.sh"
echo ""
