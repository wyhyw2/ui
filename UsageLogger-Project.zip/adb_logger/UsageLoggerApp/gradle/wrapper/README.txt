Gradle Wrapper
==============

gradle-wrapper.jar 和 gradlew 脚本通常由 Android Studio 自动生成。
如果没有，可以通过以下方式获取：

方式1: 在 Android Studio 中打开项目，它会自动生成
方式2: 手动下载 https://services.gradle.org/distributions/gradle-8.5-bin.zip
方式3: 用 `gradle wrapper` 命令生成（需要已安装 Gradle）

最简单：直接用 Android Studio 打开 UsageLoggerApp 文件夹，
它会自动创建 gradle wrapper 并下载所需依赖。
