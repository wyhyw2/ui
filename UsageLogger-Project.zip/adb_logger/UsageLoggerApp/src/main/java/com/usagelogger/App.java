package com.usagelogger;

import android.app.Application;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class App extends Application {

    private static final String LOG_FILE = "usage_log.csv";
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA);

    @Override
    public void onCreate() {
        super.onCreate();
        // 确保日志文件存在并写表头
        File logFile = new File(getExternalFilesDir(null), LOG_FILE);
        if (!logFile.exists()) {
            try {
                logFile.createNewFile();
                FileWriter fw = new FileWriter(logFile, true);
                fw.write("时间,类别,包名/UID,详情\n");
                fw.close();
            } catch (IOException ignored) {}
        }
        writeLog("APP_START", "", "===== 应用启动 =====");
    }

    private void writeLog(String category, String pkg, String detail) {
        File logFile = new File(getExternalFilesDir(null), LOG_FILE);
        String line = sdf.format(new Date()) + "," + category + "," + pkg + "," + detail + "\n";
        try {
            FileWriter fw = new FileWriter(logFile, true);
            fw.write(line);
            fw.close();
        } catch (IOException ignored) {}
    }
}
