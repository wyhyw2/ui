package com.usagelogger;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LoggerService extends Service {

    private static final int POLL_INTERVAL = 15000; // 15秒
    private Handler handler;
    private Runnable poller;
    private UsageStatsManager usageStatsManager;
    private File logFile;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA);
    private String lastForegroundPackage = "";
    private long lastSwitchTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        logFile = new File(getExternalFilesDir(null), "usage_log.csv");
        handler = new Handler(Looper.getMainLooper());
        startForegroundNotification();
        startPolling();
    }

    private void startForegroundNotification() {
        android.app.Notification.Builder builder;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            builder = new android.app.Notification.Builder(this, "usage_logger_channel")
                    .setContentTitle("使用记录器运行中")
                    .setContentText("正在后台记录您的手机使用行为")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setOngoing(true);
        } else {
            builder = new android.app.Notification.Builder(this)
                    .setContentTitle("使用记录器运行中")
                    .setContentText("正在后台记录您的手机使用行为")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setOngoing(true);
        }
        startForeground(1, builder.build());
    }

    private void startPolling() {
        poller = new Runnable() {
            @Override
            public void run() {
                checkForegroundApp();
                checkAppLaunchEvents();
                handler.postDelayed(this, POLL_INTERVAL);
            }
        };
        handler.post(poller);
    }

    private void checkForegroundApp() {
        if (usageStatsManager == null) return;
        long now = System.currentTimeMillis();
        long begin = now - POLL_INTERVAL * 2;
        UsageEvents events = usageStatsManager.queryEvents(begin, now);
        UsageEvents.Event event = new UsageEvents.Event();
        String currentFg = "";
        long currentFgTime = 0;
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                currentFg = event.getPackageName();
                currentFgTime = event.getTimeStamp();
            }
        }
        if (!currentFg.isEmpty() && !currentFg.equals(lastForegroundPackage)) {
            lastForegroundPackage = currentFg;
            lastSwitchTime = currentFgTime;
            writeLog("FOREGROUND_SWITCH", currentFg,
                    "切换到前台 | 距上次 " + ((now - lastSwitchTime) / 1000) + "s");
        }
    }

    private void checkAppLaunchEvents() {
        if (usageStatsManager == null) return;
        long now = System.currentTimeMillis();
        long begin = now - POLL_INTERVAL * 2;
        UsageEvents events = usageStatsManager.queryEvents(begin, now);
        UsageEvents.Event event = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            if (event.getEventType() == UsageEvents.Event.USER_INTERACTION) {
                writeLog("INTERACTION", event.getPackageName(), "用户交互");
            }
        }
    }

    private void writeLog(String category, String pkg, String detail) {
        String line = sdf.format(new Date()) + "," + category + "," + pkg + "," + detail + "\n";
        try {
            FileWriter fw = new FileWriter(logFile, true);
            fw.write(line);
            fw.close();
        } catch (IOException ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // 被杀后自动重启
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null && poller != null) {
            handler.removeCallbacks(poller);
        }
        writeLog("STOP", "", "===== 服务停止 =====");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
