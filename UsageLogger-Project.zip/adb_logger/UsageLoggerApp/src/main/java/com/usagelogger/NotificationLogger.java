package com.usagelogger;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotificationLogger extends NotificationListenerService {

    private static final String TAG = "NotifLogger";
    private File logFile;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA);

    @Override
    public void onCreate() {
        super.onCreate();
        logFile = new File(getExternalFilesDir(null), "usage_log.csv");
        writeLog("NOTIF_SERVICE", "", "通知监听服务已启动");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        String title = "";
        String text = "";
        if (sbn.getNotification() != null && sbn.getNotification().extras != null) {
            CharSequence t = sbn.getNotification().extras.getCharSequence("android.title");
            CharSequence tx = sbn.getNotification().extras.getCharSequence("android.text");
            title = t != null ? t.toString() : "";
            text = tx != null ? tx.toString() : "";
        }
        // 截断过长内容
        if (title.length() > 80) title = title.substring(0, 80) + "...";
        if (text.length() > 120) text = text.substring(0, 120) + "...";
        writeLog("NOTIFICATION", pkg, "标题:" + title + " | 内容:" + text);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // 可选：记录通知被清除
    }

    private void writeLog(String category, String packageName, String detail) {
        String line = sdf.format(new Date()) + "," + category + "," + packageName + "," + detail + "\n";
        try {
            FileWriter fw = new FileWriter(logFile, true);
            fw.write(line);
            fw.close();
        } catch (IOException e) {
            Log.e(TAG, "write failed", e);
        }
    }
}
