package com.usagelogger;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "usage_logger_channel";
    private static final String LOG_FILE = "usage_log.csv";
    private TextView statusText;
    private File logFile;
    private UsageStatsManager usageStatsManager;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA);

    // 广播接收器
    private BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_SCREEN_ON.equals(action)) {
                writeLog("SCREEN_ON", "", "屏幕点亮");
            } else if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                writeLog("SCREEN_OFF", "", "屏幕关闭");
            } else if (Intent.ACTION_USER_PRESENT.equals(action)) {
                writeLog("UNLOCK", "", "用户解锁");
            }
        }
    };

    private BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percent = (int) (level * 100f / scale);
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) > 0 ? "充电中" : "未充电";
            writeLog("BATTERY", "", "电量 " + percent + "% | " + plugged);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button btnStart = findViewById(R.id.btnStart);
        Button btnView = findViewById(R.id.btnView);
        Button btnGrant = findViewById(R.id.btnGrant);

        logFile = new File(getExternalFilesDir(null), LOG_FILE);
        usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);

        createNotificationChannel();

        btnGrant.setOnClickListener(v -> {
            // 引导去开启"使用情况访问"权限
            Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            startActivity(intent);
        });

        btnStart.setOnClickListener(v -> {
            if (!hasUsageStatsPermission()) {
                Toast.makeText(this, "请先授予「使用情况访问」权限", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                startActivity(intent);
                return;
            }
            startLogging();
            btnStart.setEnabled(false);
            btnStart.setText("正在记录中...");
            startForegroundService(new Intent(this, LoggerService.class));
            statusText.setText("✅ 正在后台记录\n日志文件：\n" + logFile.getAbsolutePath());
            Toast.makeText(this, "已开始记录，可放心锁屏", Toast.LENGTH_SHORT).show();
        });

        btnView.setOnClickListener(v -> {
            if (logFile.exists()) {
                StringBuilder sb = new StringBuilder();
                try {
                    java.util.Scanner sc = new java.util.Scanner(logFile);
                    int count = 0;
                    while (sc.hasNextLine() && count < 100) {
                        sb.append(sc.nextLine()).append("\n");
                        count++;
                    }
                    sc.close();
                } catch (Exception e) {}
                statusText.setText("📋 最近日志（最多100行）：\n\n" + sb.toString());
            } else {
                statusText.setText("暂无日志文件，请先点击「开始记录」");
            }
        });

        // 注册广播
        IntentFilter screenFilter = new IntentFilter();
        screenFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenFilter.addAction(Intent.ACTION_SCREEN_OFF);
        screenFilter.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(screenReceiver, screenFilter);

        IntentFilter batteryFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, batteryFilter);

        // 检查权限状态
        if (hasUsageStatsPermission()) {
            statusText.setText("✓ 权限已就绪\n点击「开始记录」即可启动");
        } else {
            statusText.setText("⚠ 需要授权\n请点击「授权」按钮，找到本应用并开启权限");
        }
    }

    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void startLogging() {
        writeLog("START", "", "===== 记录开始 =====");
        // 立即记录一次当前状态
        logCurrentForeground();
        // 启动轮询线程
        new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(10000); // 每10秒采样一次
                    logCurrentForeground();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }, "usage-poller").start();
    }

    private void logCurrentForeground() {
        if (usageStatsManager == null) return;
        long now = System.currentTimeMillis();
        long hourAgo = now - 1000 * 60 * 60; // 查最近1小时
        UsageEvents events = usageStatsManager.queryEvents(hourAgo, now);
        UsageEvents.Event event = new UsageEvents.Event();
        String lastPackage = "";
        long lastTime = 0;
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastPackage = event.getPackageName();
                lastTime = event.getTimeStamp();
            }
        }
        if (!lastPackage.isEmpty() && System.currentTimeMillis() - lastTime < 30000) {
            // 只记录最近30秒内切换到前台的
            writeLog("FOREGROUND", lastPackage, "前台应用");
        }
    }

    private void writeLog(String category, String packageName, String detail) {
        String line = sdf.format(new Date()) + "," + category + "," + packageName + "," + detail + "\n";
        try {
            FileWriter fw = new FileWriter(logFile, true);
            fw.write(line);
            fw.close();
        } catch (IOException e) {
            // ignore
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "使用记录器", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("后台记录手机使用行为");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(screenReceiver); } catch (Exception e) {}
        try { unregisterReceiver(batteryReceiver); } catch (Exception e) {}
    }
}
