#!/data/data/com.termux/files/usr/bin/bash
# =====================================================
#  手机本地使用记录器 — Termux 版
#  不需要电脑、不需要编译、不需要 root
#  在 Termux 里运行，挂在后台持续记录
# =====================================================
# 安装方式（在 Termux 里执行）：
#   pkg update && pkg install -y git curl
#   git clone <本仓库> && cd adb_logger
#   bash termux_logger.sh
#
# 或者直接在 Termux 里粘贴这段脚本运行
# =====================================================

set -e

# 颜色
R='\033[0;31m'; G='\033[0;32m'; B='\033[0;34m'; Y='\033[1;33m'; N='\033[0m'
say() { echo -e "${B}[*]${N} $*"; }
ok()  { echo -e "${G}[✓]${N} $*"; }
warn(){ echo -e "${Y}[!]${N} $*"; }
err() { echo -e "${R}[✗]${N} $*"; }

# 日志文件
LOG_DIR="$HOME/usage_logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/usage_$(date +%Y%m%d).csv"
say "日志文件: $LOG_FILE"

# 写日志
log() {
    local category="$1" pkg="$2" detail="$3"
    echo "$(date '+%Y-%m-%d %H:%M:%S'),$category,$pkg,$detail" >> "$LOG_FILE"
}

# 写表头
[ ! -s "$LOG_FILE" ] && echo "时间,类别,包名,详情" > "$LOG_FILE"

# 检查 Termux:API
if ! command -v termux-usage-stats &>/dev/null; then
    warn "需要安装 Termux:API"
    echo "  执行: pkg install -y termux-api"
    echo "  然后在 F-Droid 安装 Termux:API App"
    echo "  https://f-droid.org/packages/com.termux.api/"
    echo ""
    echo "按 Enter 继续（功能会受限）或 Ctrl+C 退出"
    read -r
fi

# 检查是否可以通过 termux-usage-stats 获取
say "检测可用数据源..."
HAS_USAGE=false
HAS_NOTIF=false
HAS_BATTERY=false
HAS_DEVICE=false

if command -v termux-usage-stats &>/dev/null; then
    HAS_USAGE=true
    ok "✓ termux-usage-stats 可用"
else
    warn "✗ termux-usage-stats 不可用（需 Termux:API）"
fi

if command -v termux-notification-list &>/dev/null; then
    HAS_NOTIF=true
    ok "✓ 通知监听可用"
fi

if command -v termux-battery-status &>/dev/null; then
    HAS_BATTERY=true
    ok "✓ 电池状态可用"
fi

if command -v termux-device-info &>/dev/null; then
    HAS_DEVICE=true
    ok "✓ 设备信息可用"
fi

# 记录设备信息
if $HAS_DEVICE; then
    DEV_INFO=$(termux-device-info 2>/dev/null | head -20)
    log "DEVICE_INFO" "" "$DEV_INFO"
fi

# 获取前台 App 的函数
get_foreground() {
    if $HAS_USAGE; then
        # 用 termux-usage-stats 拿最近前台
        termux-usage-stats -d 5 2>/dev/null | grep -oP '"package":"[^"]*"' | head -1 | cut -d'"' -f4
    else
        # 备用：读 /proc 信息（有限）
        return 1
    fi
}

# 获取电量
get_battery() {
    if $HAS_BATTERY; then
        termux-battery-status 2>/dev/null | grep -E "percentage|status" | tr '\n' ' '
    fi
}

# 主循环
say "开始记录... 按 Ctrl+C 停止"
log "START" "" "===== 记录开始 ====="

# 后台电量监控
monitor_battery() {
    while true; do
        STATUS=$(get_battery)
        [ -n "$STATUS" ] && log "BATTERY" "" "$STATUS"
        sleep 300  # 每5分钟
    done
}

# 后台通知监控
monitor_notifications() {
    while true; do
        if $HAS_NOTIF; then
            termux-notification-list 2>/dev/null | while IFS= read -r line; do
                PKG=$(echo "$line" | grep -oP '"package":"[^"]*"' | cut -d'"' -f4)
                TITLE=$(echo "$line" | grep -oP '"title":"[^"]*"' | cut -d'"' -f4)
                [ -n "$PKG" ] && log "NOTIFICATION" "$PKG" "标题:$TITLE"
            done
        fi
        sleep 30
    done
}

# 后台前台监控
monitor_foreground() {
    local last=""
    while true; do
        local fg=$(get_foreground)
        if [ -n "$fg" ] && [ "$fg" != "$last" ]; then
            log "FOREGROUND" "$fg" "切换到前台"
            last="$fg"
        fi
        sleep 10
    done
}

# 启动监控
monitor_battery &
PID_BAT=$!
monitor_foreground &
PID_FG=$!

ok "已启动 3 个监控线程"
ok "后台运行中，可锁屏或退出 Termux（用 exit 而非 Ctrl+C）"
echo ""
echo "查看实时日志:"
echo "  tail -f $LOG_FILE"
echo ""
echo "导出日志:"
echo "  cp $LOG_FILE /sdcard/Download/"
echo ""

# 前台也输出摘要
trap 'kill $PID_BAT $PID_FG 2>/dev/null; log "STOP" "" "===== 记录结束 ====="; ok "已停止，日志保存在 $LOG_FILE"; exit 0' INT

# 主线程：每 60 秒打印一次状态
while true; do
    COUNT=$(wc -l < "$LOG_FILE")
    LAST=$(tail -1 "$LOG_FILE")
    echo -e "${G}[$(date +%H:%M:%S)]${N} 已记录 ${Y}$COUNT${N} 条 | 最近: $LAST"
    sleep 60
done
