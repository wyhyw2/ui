#!/data/data/com.termux/files/usr/bin/bash
# =====================================================
#  使用记录器 — Termux 极简版（无需 Termux:API）
#  纯 shell，记录能拿到的所有信息
# =====================================================
# 安装: pkg update && pkg install -y procps lsof
# 运行: bash termux_simple.sh
# =====================================================

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; B='\033[0;34m'; N='\033[0m'
LOG_DIR="$HOME/usage_logs"; mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/usage_$(date +%Y%m%d).csv"
[ ! -s "$LOG" ] && echo "时间,类别,包名,详情" > "$LOG"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S'),$1,$2,$3" >> "$LOG"; }

# 能用的工具
HAS_PS=false; HAS_LSOF=false; HAS_TOP=false
command -v ps &>/dev/null && HAS_PS=true
command -v lsof &>/dev/null && HAS_LSOF=true
command -v top &>/dev/null && HAS_TOP=true

echo -e "${B}╔══════════════════════════════════╗${N}"
echo -e "${B}║   手机使用记录器 — Termux 版     ║${N}"
echo -e "${B}╚══════════════════════════════════╝${N}"
echo ""
echo "日志: $LOG"
echo "可用工具: ps=$HAS_PS lsof=$HAS_LSOF top=$HAS_TOP"
echo ""

log "START" "" "===== 记录开始 ====="

# 记录运行中的进程快照
snapshot_processes() {
    if $HAS_PS; then
        local count=$(ps -e --no-headers 2>/dev/null | wc -l)
        log "PROC_SNAPSHOT" "" "运行中进程数: $count"
        # 记录前10个用户进程
        ps -e --no-headers -o pid,user,comm 2>/dev/null | grep -v "^ *[0-9]* root" | head -10 | while read pid user comm; do
            log "PROC" "$comm" "PID=$pid UID=$user"
        done
    fi
}

# 记录网络连接
snapshot_network() {
    if $HAS_LSOF; then
        lsof -i 2>/dev/null | grep -E "ESTABLISHED|LISTEN" | head -20 | while read line; do
            log "NETWORK" "" "$line"
        done
    fi
}

# 记录电量（Termux 自带）
check_battery() {
    # Termux 暴露电量在 /sys/class/power_supply/
    local batt=""
    [ -r /sys/class/power_supply/battery/capacity ] && batt="电量 $(cat /sys/class/power_supply/battery/capacity)%"
    [ -r /sys/class/power_supply/Battery/capacity ] && batt="电量 $(cat /sys/class/power_supply/Battery/capacity)%"
    local status=""
    [ -r /sys/class/power_supply/battery/status ] && status=$(cat /sys/class/power_supply/battery/status)
    [ -n "$batt" ] && log "BATTERY" "" "$batt | $status"
}

# 记录内存
check_memory() {
    local mem=$(free -m 2>/dev/null | awk '/Mem:/ {print "总计"$2"MB 已用"$3"MB 空闲"$4"MB"}')
    [ -n "$mem" ] && log "MEMORY" "" "$mem"
}

# 记录开机时长
check_uptime() {
    local up=$(uptime 2>/dev/null)
    [ -n "$up" ] && log "UPTIME" "" "$up"
}

# 尝试读取 /proc 中的前台信息
check_foreground_proc() {
    # 在 Termux 里能看到自己的进程，看不到其他 App 的
    # 但能监控到系统级事件
    :
}

say() { echo -e "${B}[*]${N} $*"; }
ok() { echo -e "${G}[✓]${N} $*"; }

say "开始持续记录（每 30 秒一次快照）..."
say "按 Ctrl+C 停止"

trap 'log "STOP" "" "===== 记录结束 ====="; echo ""; ok "已停止"; ok "日志: $LOG"; exit 0' INT

# 立即记一次
check_battery
snapshot_processes
check_memory

while true; do
    # 每30秒
    sleep 30
    check_battery
    check_uptime
    # 每5分钟
    if [ $(( $(date +%M) % 5 )) -eq 0 ]; then
        snapshot_processes
        snapshot_network
        check_memory
    fi
    # 打印状态
    local lines=$(wc -l < "$LOG")
    echo -e "${G}[$(date +%H:%M:%S)]${N} 已记录 ${Y}$lines${N} 条"
done
