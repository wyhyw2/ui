#!/bin/bash
# =====================================================
#  一键部署到 GitHub — 自动编译 APK
#  小白也能用：执行这个脚本，自动创建仓库+上传代码
#  GitHub Actions 会自动编译出 APK
# =====================================================
set -e

G='\033[0;32m'; B='\033[0;34m'; Y='\033[1;33m'; R='\033[0;31m'; N='\033[0m'

echo -e "${B}"
echo "╔════════════════════════════════════════════╗"
echo "║   GitHub 自动编译 APK — 一键部署脚本        ║"
echo "╚════════════════════════════════════════════╝"
echo -e "${N}"
echo ""
echo "你需要有一个 GitHub 账号（免费注册：https://github.com）"
echo ""

# 检查 gh 是否安装
if ! command -v gh &>/dev/null; then
    echo -e "${Y}[!] 需要先安装 GitHub CLI${N}"
    echo ""
    echo "方式 1（推荐）：访问 https://cli.github.com 下载安装"
    echo ""
    echo "方式 2：如果是 Termux，执行："
    echo "  pkg install -y gh"
    echo ""
    echo "方式 3：如果是 Ubuntu/Debian："
    echo "  sudo apt install -y gh"
    echo ""
    echo "安装完后重新运行这个脚本"
    exit 1
fi

echo -e "${G}[✓]${N} GitHub CLI 已安装"
echo ""

# 检查登录状态
if ! gh auth status &>/dev/null; then
    echo -e "${Y}[!] 请先登录 GitHub${N}"
    echo ""
    gh auth login --hostname github.com --git-protocol https --web
    echo ""
fi

echo -e "${G}[✓]${N} 已登录 GitHub"
echo ""

# 获取用户名
GH_USER=$(gh api user --jq .login 2>/dev/null)
echo -e "${B}账号:${N} $GH_USER"
echo ""

# 设置仓库名
REPO_NAME="usagelogger"
echo -e "${B}仓库名:${N} $REPO_NAME"
echo ""

# 确认
read -p "确认创建仓库 '$REPO_NAME' 并上传？(y/n) " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "已取消"
    exit 0
fi

echo ""
say() { echo -e "${B}[*]${N} $*"; }
ok()  { echo -e "${G}[✓]${N} $*"; }

# 进入项目目录
cd "$(dirname "$0")"

# 清理不需要上传的文件
say "清理临时文件..."
rm -rf UsageLoggerApp/.gradle 2>/dev/null || true
rm -rf UsageLoggerApp/build 2>/dev/null || true
rm -rf __pycache__ 2>/dev/null || true
rm -f *.zip 2>/dev/null || true
ok "清理完成"

# 创建 README（GitHub 版）
say "创建 GitHub README..."
cat > README.md << 'EOF'
# 📱 使用记录器 (Usage Logger)

> 记录你的手机使用行为，检测是否有异常活动。
> 日志存手机内部存储，不上传任何服务器。

## ✨ 功能

- 📊 **前台 App 时间线** — 记录每次打开/切换 App 的时间
- 🔓 **解锁/锁屏** — 记录每次亮屏和解锁
- 🔔 **通知记录** — 记录所有收到的通知（标题+内容）
- 🔋 **电量变化** — 记录电量百分比和充电状态
- 🚀 **后台保活** — 前台服务 + 开机自启
- 🔒 **完全离线** — 无网络权限，数据不出手机

## 📦 下载 APK

1. 点击上方 **Actions** 标签
2. 选择最新的 **Build APK** 工作流
3. 点击 **UsageLogger-APK** 下载
4. 传到手机安装即可

## 📖 使用教程

安装后打开 App → 点「授权」开启使用情况访问 → 点「开始记录」→ 完成！

详细教程见压缩包内的 `README_APP.md`。

## 📋 日志格式

```csv
时间,类别,包名,详情
2026-07-23 14:03:22,FOREGROUND,com.tencent.mm,切换到前台
2026-07-23 14:05:00,UNLOCK,,用户解锁
2026-07-23 14:06:30,NOTIFICATION,com.tencent.mm,标题:微信|内容:新消息
2026-07-23 14:10:00,BATTERY,,电量 78% | 未充电
```

日志位置：`内部存储/Android/data/com.usagelogger/files/usage_log.csv`

## 🔒 隐私说明

- 不申请网络权限
- 所有数据仅存于本机
- 开源代码，可完整审计

## 📜 License

MIT
EOF
ok "README 创建完成"

# 初始化 git
say "初始化 Git 仓库..."
if [ ! -d .git ]; then
    git init -b main
fi

# 创建 .gitignore
cat > .gitignore << 'EOF'
*.iml
.gradle/
build/
local.properties
.idea/
*.apk
*.aab
.DS_Store
__pycache__/
*.pyc
EOF

# 添加文件
git add .
git commit -m "feat: 使用记录器完整项目 + GitHub Actions 自动编译" 2>/dev/null || git commit --allow-empty -m "init"

# 创建 GitHub 仓库
say "创建 GitHub 仓库..."
gh repo create "$REPO_NAME" --public --source=. --description "Android 使用行为记录器 — 自动编译APK" --push 2>&1 && ok "仓库创建并推送成功" || {
    echo -e "${Y}[!] 仓库可能已存在，尝试推送...${N}"
    git remote remove origin 2>/dev/null || true
    git remote add origin "https://github.com/$GH_USER/$REPO_NAME.git"
    git push -u origin main 2>&1 && ok "推送成功" || {
        echo -e "${R}[✗] 推送失败${N}"
        echo "可能仓库名冲突，换个名字试试："
        echo "  git remote set-url origin https://github.com/$GH_USER/usagelogger-app.git"
        echo "  git push -u origin main"
        exit 1
    }
}

echo ""
echo -e "${G}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo -e "  ${G}✅ 全部完成！${N}"
echo ""
echo -e "  🔗 仓库地址: ${B}https://github.com/$GH_USER/$REPO_NAME${N}"
echo ""
echo -e "  ${Y}接下来（等 3-5 分钟）：${N}"
echo ""
echo "  1. 打开上面的仓库地址"
echo "  2. 点上方 ${B}Actions${N} 标签"
echo "  3. 看到 ${G}✓ Build APK${N} 变绿色 = 编译成功"
echo "  4. 点进去 → 右侧下载 ${B}UsageLogger-APK${N}"
echo "  5. 把 APK 传到手机 → 安装 → 完成！"
echo ""
echo -e "  ${R}注意：${N} 第一次可能需要在 Actions 页面点一下"
echo "  'I understand my workflows' 按钮启用自动编译"
echo ""
echo -e "${G}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
