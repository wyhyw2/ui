# 📱 使用记录器 (Usage Logger)

> 记录你的手机使用行为，检测是否有异常活动。
> **完全离线，数据不出手机。**

---

## ✨ 功能

| 功能 | 说明 |
|---|---|
| 📊 前台 App 时间线 | 记录每次打开/切换 App 的时间 |
| 🔓 解锁/锁屏 | 记录每次亮屏和解锁 |
| 🔔 通知记录 | 记录所有收到的通知（标题+内容） |
| 🔋 电量变化 | 记录电量百分比和充电状态 |
| 🚀 后台保活 | 前台服务 + 开机自启 + 被杀自动重启 |
| 🔒 完全离线 | 无网络权限，数据 100% 留本机 |

---

## 📦 获取 APK — 3 分钟搞定

**你不需要装任何软件。** 跟着教程做就行：

👉 **[打开图文教程](HOW_TO_GET_APK.html)** ← 点这里

教程步骤概要：
1. 注册 GitHub 账号（免费，2 分钟）
2. 上传代码到仓库（3 分钟）
3. 等 GitHub 自动编译（3-5 分钟）
4. 下载 APK 安装到手机

---

## 📖 安装后怎么用

1. 打开「使用记录器」App
2. 点 **「🔐 授权」** → 找到本 App → 开启"使用情况访问"
3. 返回 → 点 **「▶ 开始记录」**
4. 通知栏出现"使用中" = 成功！

### 防被杀设置（OPPO/vivo 必做）

**OPPO:** 设置 → 电池 → 自启动管理 → 允许本 App
**vivo:** i管家 → 自启动 → 开启本 App
**通用:** 最近任务卡片下拉锁定（出小锁 🔒）

---

## 📋 日志长什么样

```csv
时间,类别,包名,详情
2026-07-23 14:03:22,FOREGROUND,com.tencent.mm,切换到前台
2026-07-23 14:05:00,UNLOCK,,用户解锁
2026-07-23 14:06:30,NOTIFICATION,com.tencent.mm,标题:微信|内容:新消息
2026-07-23 14:10:00,BATTERY,,电量 78% | 未充电
```

**日志位置：** `内部存储/Android/data/com.usagelogger/files/usage_log.csv`

用 Excel / WPS 打开，可以做数据透视表分析。

---

## 🔒 隐私说明

- ✅ 不申请网络权限
- ✅ 所有数据仅存于本机
- ✅ 开源代码，可完整审计
- ✅ 不收集任何个人信息

---

## 📂 项目结构

```
usagelogger/
├── .github/workflows/build-apk.yml   # GitHub 自动编译配置
├── UsageLoggerApp/                    # Android App 源码
│   ├── src/main/java/.../           # Java 源码（5个文件）
│   ├── src/main/res/                # 界面布局和资源
│   ├── src/main/AndroidManifest.xml # 权限和组件声明
│   ├── build.gradle                 # 模块构建配置
│   └── proguard-rules.pro
├── HOW_TO_GET_APK.html              # 📖 图文教程（小白必看）
├── README_APP.md                    # 详细使用文档
├── setup_github.sh                  # 一键部署到 GitHub
└── QUICKSTART.txt                   # 快速开始
```

---

## 📜 License

MIT License — 随便用，随便改。
